Config = {}
VehicleConfigs = nil
CurrentTime = 0
SpeedLimit = 0.0
LastPlayedOptilink = GetGameTimer()

Citizen.CreateThread(function()
	PerformInitialisation()
	while true do
		CurrentTime = GetGameTimer()

		ProcessCurrentVehicle()

		CheckVehicleStates()

		ProcessVehicleLights()
		
		Citizen.Wait(1)
	end
end)

function PerformInitialisation()
	local resourceName = GetCurrentResourceName()

	local config = LoadResourceFile(resourceName, "config.json")
	Config = json.decode(config)

	Config.Pattern = {}

	local primary = LoadResourceFile(resourceName, "patterns/primary.json")
	Config.Pattern["PRIMARY"] = json.decode(primary)

	local rearPrimary = LoadResourceFile(resourceName, "patterns/rearPrimary.json")
	Config.Pattern["REARPRIMARY"] = json.decode(rearPrimary)

	local secondary = LoadResourceFile(resourceName, "patterns/secondary.json")
	Config.Pattern["SECONDARY"] = json.decode(secondary)

	local warning = LoadResourceFile(resourceName, "patterns/warning.json")
	Config.Pattern["WARNING"] = json.decode(warning)

	local luke = LoadResourceFile(resourceName, "patterns/luke.json")
	Config.Pattern["LUKE"] = json.decode(luke)

	local vcfs = LoadResourceFile(resourceName, "vcfs/_list.json")
	vcfs = json.decode(vcfs)

	VehicleConfigs = {}

	for i, v in ipairs(vcfs) do
		local vcf = LoadResourceFile(resourceName, "vcfs/" .. v .. ".json")

		if vcf then
			local isSuccessful, errorMsg = pcall(function()
				local vehicle = json.decode(vcf)
				vehicle.name = v
				VehicleConfigs[GetHashKey(v)] = vehicle
			end)

			if not isSuccessful then
				print("Unable to load VCF for " .. v .. " (" .. errorMsg .. ")")
			end
		else
			print("Unable to locate VCF file for " .. v)
		end
	end

	-- Cleans up ~20MB of memory
	collectgarbage("collect")

	RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_ONE", false)
    RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_TWO", false)
    RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_THREE", false)
    RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_FOUR", false)
    RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_FIVE", false)
	RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_SIX", false)
    RequestAmbientAudioBank("DLC_XCUSTOM\\XSIRENS_SEVEN", false)
end

local gameTimer = GetGameTimer()

function ProcessCurrentVehicle()
	local myPed = PlayerPedId()
	local vehicle = GetVehiclePedIsIn(myPed, false)

	if vehicle == 0 then return end

	if SpeedLimit ~= 0.0 then
		SetVehicleMaxSpeed(vehicle, SpeedLimit)
	end

	local model = GetEntityModel(vehicle)

	if not VehicleConfigs[model] then return end

	if not (GetPedInVehicleSeat(vehicle, -1) == myPed) and not (GetPedInVehicleSeat(vehicle, 0) == myPed) then return end

	DisableControlAction(0, 81, true)
	DisableControlAction(0, 82, true)
	DisableControlAction(0, 83, true)
	DisableControlAction(0, 84, true)
	DisableControlAction(0, 85, true)

	SetVehRadioStation(vehicle, "OFF")
	SetVehicleRadioEnabled(vehicle, false)
	SetVehicleHasMutedSirens(vehicle, true)

	if GetLastInputMethod(0) then
		DisableControlAction(0, Config.Keyboard.PrimaryLights, true)
		DisableControlAction(0, Config.Keyboard.SecondaryLights, true)
		DisableControlAction(0, Config.Keyboard.WarningLights, true)
		DisableControlAction(0, Config.Keyboard.SirenToggle, true)
		DisableControlAction(0, Config.Keyboard.SirenSwitch, true)
		DisableControlAction(0, Config.Keyboard.Bullhorn, true)
		DisableControlAction(0, Config.Keyboard.IndicatorLeft, true)
		DisableControlAction(0, Config.Keyboard.IndicatorRight, true)
		DisableControlAction(0, Config.Keyboard.Hazard, true)

		if IsDisabledControlJustPressed(0, Config.Keyboard.PrimaryLights) then
			OnKeyStageChange(vehicle)
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.SecondaryLights) then
			OnKeyPattern(vehicle, "SECONDARY")
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.WarningLights) then
			OnKeyPattern(vehicle, "WARNING")
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.SirenToggle) then
			OnKeySirenToggle(vehicle)
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.SirenSwitch) then
			OnKeySirenSwitch(vehicle, true)
		end

		if IsDisabledControlJustReleased(0, Config.Keyboard.SirenSwitch) then
			OnKeySirenSwitch(vehicle, false)
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.Bullhorn) then
			OnKeyBullhorn(vehicle, true)
		end

		if IsDisabledControlJustReleased(0, Config.Keyboard.Bullhorn) then
			OnKeyBullhorn(vehicle, false)
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.IndicatorLeft) then
			local lights = GetVehicleIndicatorLights(vehicle)
			local enabled = not (lights == 1)
			TriggerServerEvent("ELS:IndicatorChange", 1, enabled)
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.IndicatorRight) then
			local lights = GetVehicleIndicatorLights(vehicle)
			local enabled = not (lights == 2)
			TriggerServerEvent("ELS:IndicatorChange", 2, enabled)
		end

		if IsDisabledControlJustPressed(0, Config.Keyboard.Hazard) then
			local lights = GetVehicleIndicatorLights(vehicle)
			local enabled = not (lights == 3)
			TriggerServerEvent("ELS:IndicatorChange", 3, enabled)
		end
	else
		DisableControlAction(0, Config.Controller.PrimaryLights, true)
		DisableControlAction(0, Config.Controller.SirenToggle, true)
		DisableControlAction(0, Config.Controller.SirenSwitch, true)
		DisableControlAction(0, Config.Controller.Bullhorn, true)

		if IsDisabledControlJustPressed(0, Config.Controller.PrimaryLights) then
			OnKeyStageChange(vehicle)
		end

		if IsDisabledControlJustPressed(0, Config.Controller.SirenToggle) then
			OnKeySirenToggle(vehicle)
		end

		if IsDisabledControlJustPressed(0, Config.Controller.SirenSwitch) then
			OnKeySirenSwitch(vehicle, true)
		end

		if IsDisabledControlJustReleased(0, Config.Controller.SirenSwitch) then
			OnKeySirenSwitch(vehicle, false)
		end

		if IsDisabledControlJustPressed(0, Config.Controller.Bullhorn) then
			OnKeyBullhorn(vehicle, true)
		end

		if IsDisabledControlJustReleased(0, Config.Controller.Bullhorn) then
			OnKeyBullhorn(vehicle, false)
		end
	end
end

function ProcessVehicleLights()
	for k, v in pairs(EnabledVehicles) do
		local state = SavedVehicles[k]

		SetVehicleAutoRepairDisabled(state.entity, true)
		SetVehicleHasMutedSirens(state.entity, true)

		Controller.CheckPatterns(state)
	end
end

function ELSStageChangeForVehicle(vehicle)
	local state = GetSavedVehicleStateUsingEntity(vehicle)

	state.stage = state.stage + 1
	if state.stage == 3 then state.stage = 0 end


	Controller.OnStageChange(state)

	TriggerServerEvent("ELS:ChangeStage", state.stage)
end
function OnKeyStageChange(vehicle)
	local state = GetSavedVehicleStateUsingEntity(vehicle)

	state.stage = state.stage + 1
	if state.stage == 3 then state.stage = 0 end

	if state.stage == 1 then
		if tostring(string.sub(state.config.name, 0, 3)) == "LAS" then
			TriggerEvent("Core-Sounds:playonown", "999mode", 1.0)
		end
	end

	Controller.OnStageChange(state)

	if SpeedLimit ~= 0.0 then
		SpeedLimit = 0.0
		SetVehicleMaxSpeed(vehicle, 0.0)
		BeginTextCommandPrint("CELL_EMAIL_BCON")
		AddTextComponentSubstringPlayerName("Speed limiter removed")
		EndTextCommandPrint(2000, true)
	end

	TriggerServerEvent("ELS:ChangeStage", state.stage)
end

function OnKeySirenToggle(vehicle)
	local state = GetSavedVehicleStateUsingEntity(vehicle)

	if not state.siren.configEnabled then return end

	if state.stage == 0 or state.stage == 2 then return end

	state.siren.enabled = not state.siren.enabled

	state.siren.tone = (state.siren.enabled) and 1 or 0

	Controller.OnSirenChange(state)

	TriggerServerEvent("ELS:ToggleSiren", state.siren.tone)

	Citizen.CreateThread(function()
		TriggerEvent("Core-Sounds:playonown", "beepbeep", 0.08)
	end)
end

function OnKeySirenSwitch(vehicle, isDown)
	local state = GetSavedVehicleStateUsingEntity(vehicle)
	
	if not state.siren.configEnabled then return end

	if state.stage == 0 then return end

	if state.siren.enabled then
		if not isDown then return end

		state.siren.tone = state.siren.tone + 1
		if state.siren.tone > #state.siren.sounds then state.siren.tone = 1 end

		Citizen.CreateThread(function()
			TriggerEvent("Core-Sounds:playonown", "beep", 0.08)
		end)
	else
		if isDown then
			state.siren.tone = 1
		else
			state.siren.tone = 0
		end
	end

	Controller.OnSirenChange(state)

	TriggerServerEvent("ELS:ToggleSiren", state.siren.tone)
end

function OnKeyBullhorn(vehicle, enable)
	local state = GetSavedVehicleStateUsingEntity(vehicle)

	if not state.bullhorn.configEnabled then return end

	if state.bullhorn.enabled == enable then return end

	state.bullhorn.enabled = enable

	Controller.OnBullhornChange(state)

	TriggerServerEvent("ELS:ToggleBullhorn", enable)
end

function OnKeyPattern(vehicle, patternName)
	local state = GetSavedVehicleStateUsingEntity(vehicle)

	local pattern = state.pattern[patternName]
	pattern.enabled = not pattern.enabled
	if not pattern.enabled then 
		Controller.OnPatternDisable(state, patternName)
	end

	TriggerServerEvent("ELS:PatternChange", patternName, pattern.enabled)
end

RegisterCommand("els_speedlimit", function()
	local veh = GetVehiclePedIsUsing(PlayerPedId())
	if veh == 0 then return end

	if SpeedLimit == 0.0 then
		local speed = GetEntitySpeed(veh)
		local mph = speed * 2.236

		if mph >= 15.0 then
			SpeedLimit = speed
			BeginTextCommandPrint("CELL_EMAIL_BCON")
			AddTextComponentSubstringPlayerName("Speed limiter set to " .. tostring(math.floor(mph + 0.5)) .. " MPH")
			EndTextCommandPrint(2000, true)
		else
			BeginTextCommandPrint("CELL_EMAIL_BCON")
			AddTextComponentSubstringPlayerName("Speed limiter unable to be set")
			EndTextCommandPrint(2000, true)
		end
	else
		BeginTextCommandPrint("CELL_EMAIL_BCON")
		AddTextComponentSubstringPlayerName("Speed limiter removed")
		EndTextCommandPrint(2000, true)

		SpeedLimit = 0.0
		SetVehicleMaxSpeed(veh, 0.0)
	end
end)

RegisterCommand("speedlimit", function(source, args, raw)
	if not args[1] then return end

	local mph = tonumber(args[1])
	if not mph then return end

	local ms = mph / 2.236

	SpeedLimit = ms
	BeginTextCommandPrint("CELL_EMAIL_BCON")
	AddTextComponentSubstringPlayerName("Speed limiter set to " .. tostring(math.floor(mph + 0.5)) .. " MPH")
	EndTextCommandPrint(2000, true) 
end)

RegisterKeyMapping("els_speedlimit", "Speed Limit", "KEYBOARD", "M")