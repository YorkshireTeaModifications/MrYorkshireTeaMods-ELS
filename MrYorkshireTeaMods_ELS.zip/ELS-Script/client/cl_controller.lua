Controller = {}

function Controller.CheckPatterns(state)
	local isAnyPatternEnabled = false

	for name, pattern in pairs(state.pattern) do
		if pattern.enabled then
			isAnyPatternEnabled = true

			local currentStage = pattern.stages[pattern.current]

			if CurrentTime - pattern.updated > currentStage.Milliseconds then
				pattern.current = pattern.current + 1
				if pattern.current > #pattern.stages then pattern.current = 1 end

				local nextStage = pattern.stages[pattern.current]
				Controller.MoveToPattern(state.entity, currentStage, nextStage)
				currentStage = nextStage

				pattern.updated = CurrentTime
			end

			for i = 1, #currentStage.Extras do
				local id = currentStage.Extras[i]
				Controller.DrawEnviromentLighting(state, id)
			end
		end
	end

	if isAnyPatternEnabled then
		SetVehicleEngineOn(state.entity, true, true, false)
	end
end

function Controller.MoveToPattern(entity, last, new)
	for i = 1, #last.Extras do
		SetVehicleExtra(entity, last.Extras[i], true)
	end

	for i = 1, #new.Extras do
		SetVehicleExtra(entity, new.Extras[i], false)
	end
end

function Controller.DrawEnviromentLighting(state, extraId)
	local extra = state.extras[extraId]
	if not extra then return end

	if not extra.lighting then return end

	local entity = state.entity

	if not extra.index then
		extra.index = GetEntityBoneIndexByName(entity, "extra_" .. extraId)
	end

	local pos = GetEntityCoords(entity, true)

	for i, v in ipairs(extra.rotations) do
		local coords = GetWorldPositionOfEntityBone(entity, entityBone)
		local offset = GetOffsetFromEntityInWorldCoords(entity, v.x, v.y, v.z)
		local difference = offset - pos
		local direction = norm(difference)

		local colour = extra.colour
		if colour == "blue" then
			DrawSpotLight(coords.x, coords.y, coords.z, direction, 0, 0, 255, 60.0, 1.0, 0.0, 45.0, 100.0)
		elseif colour == "red" then
			DrawSpotLight(coords.x, coords.y, coords.z, direction, 255, 0, 0, 60.0, 1.0, 0.0, 45.0, 100.0)
		elseif colour == "green" then
			DrawSpotLight(coords.x, coords.y, coords.z, direction, 0, 255, 0, 60.0, 1.0, 0.0, 45.0, 100.0)
		elseif colour == "white" then
			DrawSpotLight(coords.x, coords.y, coords.z, direction, 255, 255, 255, 60.0, 1.0, 0.0, 45.0, 100.0)
		elseif colour == "alley" then
			DrawLightWithRangeAndShadow(coords.x, coords.y, coords.z, 255, 255, 255, 30.0, 0.80, 2.0)
		elseif colour == "amber" then
			DrawSpotLight(coords.x, coords.y, coords.z, direction, 255, 194, 0, 60.0, 1.0, 0.0, 45.0, 100.0)
		end 
	end
end

function Controller.OnStageChange(state)
	if state.stage == 0 then
		state.pattern["PRIMARY"].enabled = false
		Controller.OnPatternDisable(state, "PRIMARY")

		state.pattern["REARPRIMARY"].enabled = false
		Controller.OnPatternDisable(state, "REARPRIMARY")

		state.pattern["SECONDARY"].enabled = false
		Controller.OnPatternDisable(state, "SECONDARY")

		state.pattern["WARNING"].enabled = false
		Controller.OnPatternDisable(state, "WARNING")

		state.siren.tone = 0
		state.siren.enabled = false
		Controller.OnSirenChange(state)

		SetVehicleSiren(state.entity, false)

	elseif state.stage == 1 then
		state.pattern["PRIMARY"].enabled = true

		if state.config then
			if state.config.secondaryWithPrimary then
				state.pattern["SECONDARY"].enabled = true
			end

			if state.config.warningWithPrimary then
				state.pattern["WARNING"].enabled = true
			end
		end

		SetVehicleSiren(state.entity, true)

	elseif state.stage == 2 then
		state.pattern["PRIMARY"].enabled = false
		Controller.OnPatternDisable(state, "PRIMARY")

		state.pattern["REARPRIMARY"].enabled = true
		state.pattern["SECONDARY"].enabled = true

		state.siren.tone = 0
		state.siren.enabled = false
		Controller.OnSirenChange(state)

		SetVehicleSiren(state.entity, true)
	end
end

function Controller.OnPatternDisable(state, patternName)
	local pattern = state.pattern[patternName]
	if not pattern.enabled then
		local disabled = {}
		for i, v in ipairs(pattern.stages) do
			for i = 1, #v.Extras do
				local extra = v.Extras[i]
				if not disabled[extra] then
					SetVehicleExtra(state.entity, extra, true)
					disabled[extra] = true
				end
			end
		end
	end
end

function Controller.OnBullhornChange(state)
	if not state.entity then return end

	if state.bullhorn.enabled then
		state.bullhorn.handle = GetSoundId()
		if state.bullhorn.sound == "whistle" then
			PlaySoundFromEntity(state.bullhorn.handle, state.bullhorn.sound, state.entity, "DLC_TG_Running_Back_Sounds", 0, 0)
		else
			PlaySoundFromEntity(state.bullhorn.handle, state.bullhorn.sound, state.entity, "DLC_XCUSTOM_SOUNDSET", 0, 0)
		end

		if state.siren.tone ~= 0 then
			local tone = state.siren.tone
			state.siren.tone = 0
			Controller.OnSirenChange(state)
			state.siren.tone = tone
		end
	else
		if state.bullhorn.handle ~= nil then
			StopSound(state.bullhorn.handle)
			ReleaseSoundId(state.bullhorn.handle)
			state.bullhorn.handle = nil
		end

		if state.siren.tone ~= 0 and not state.siren.handle then
			Controller.OnSirenChange(state)
		end
	end
end

function Controller.OnSirenChange(state)
	if not state.entity then return end

	if state.siren.tone ~= 0 then
		if state.siren.handle then
			StopSound(state.siren.handle)
			ReleaseSoundId(state.siren.handle)
			state.siren.handle = nil
		end

		local soundName = state.siren.sounds[state.siren.tone]

		state.siren.handle = GetSoundId()
		PlaySoundFromEntity(state.siren.handle, soundName, state.entity, "DLC_XCUSTOM_SOUNDSET", 0, 0)
	else
		if state.siren.handle ~= nil then
			StopSound(state.siren.handle)
			ReleaseSoundId(state.siren.handle)
			state.siren.handle = nil
		end
	end
end