SavedVehicles = {}
EnabledVehicles = {}
PlayerServerId = GetPlayerServerId(PlayerId())

RegisterNetEvent("ELS:ChangeStage")
AddEventHandler("ELS:ChangeStage", function(player, netId, stage)
	if player == PlayerServerId then return end

	if not VehicleConfigs then return end

	local state = GetSavedVehicleState(netId)

	state.stage = stage
	Controller.OnStageChange(state)
end)

RegisterNetEvent("ELS:ToggleSiren")
AddEventHandler("ELS:ToggleSiren", function(player, netId, tone)
	if player == PlayerServerId then return end

	if not VehicleConfigs then return end

	local state = GetSavedVehicleState(netId)

	state.siren.tone = tone
	if tone == 0 then
		state.siren.enabled = false
	else
		state.siren.enabled = true
	end
	
	Controller.OnSirenChange(state)
end)

RegisterNetEvent("ELS:ToggleBullhorn")
AddEventHandler("ELS:ToggleBullhorn", function(player, netId, enabled)
	if player == PlayerServerId then return end

	if not VehicleConfigs then return end

	local state = GetSavedVehicleState(netId)

	state.bullhorn.enabled = enabled

	Controller.OnBullhornChange(state)
end)

RegisterNetEvent("ELS:PatternChange")
AddEventHandler("ELS:PatternChange", function(player, netId, pattern, enabled)
	if player == PlayerServerId then return end

	if not VehicleConfigs then return end

	local state = GetSavedVehicleState(netId)

	state.pattern[pattern].enabled = enabled
end)

--[[RegisterNetEvent("ELS:IndicatorChange")
AddEventHandler("ELS:IndicatorChange", function(netId, mode, enabled)
	if not VehicleConfigs then return end

	local state = GetSavedVehicleState(netId)

	if not state.entity then return end

	if mode == 1 then
		SetVehicleIndicatorLights(state.entity, 0, false)
		SetVehicleIndicatorLights(state.entity, 1, enabled)
	elseif mode == 2 then
		SetVehicleIndicatorLights(state.entity, 0, enabled)
		SetVehicleIndicatorLights(state.entity, 1, false)
	elseif mode == 3 then
		SetVehicleIndicatorLights(state.entity, 1, enabled)
		SetVehicleIndicatorLights(state.entity, 0, enabled)
	end
end)]]

RegisterNetEvent("ELS:VehicleRemoved")
AddEventHandler("ELS:VehicleRemoved", function(netId)
	local state = SavedVehicles[netId]

	if not VehicleConfigs then return end

	if state then VehicleLeftScope(netId, state) end

	SavedVehicles[netId] = nil
end)

function GetSavedVehicleState(netId)
	local state = SavedVehicles[netId]

	if state then return state end

	state = {}
	state.stage = 0

	state.siren = {}
	state.siren.tone = 0
	state.siren.enabled = false

	state.bullhorn = {}
	state.bullhorn.enabled = false

	state.pattern = {}
	state.pattern["PRIMARY"] = {}
	state.pattern["PRIMARY"].enabled = false
	state.pattern["PRIMARY"].current = 1
	state.pattern["PRIMARY"].updated = 0
	state.pattern["PRIMARY"].stages = {}

	state.pattern["REARPRIMARY"] = {}
	state.pattern["REARPRIMARY"].enabled = false
	state.pattern["REARPRIMARY"].current = 1
	state.pattern["REARPRIMARY"].updated = 0
	state.pattern["REARPRIMARY"].stages = {}

	state.pattern["SECONDARY"] = {}
	state.pattern["SECONDARY"].enabled = false
	state.pattern["SECONDARY"].current = 1
	state.pattern["SECONDARY"].updated = 0
	state.pattern["SECONDARY"].stages = {}

	state.pattern["WARNING"] = {}
	state.pattern["WARNING"].enabled = false
	state.pattern["WARNING"].current = 1
	state.pattern["WARNING"].updated = 0
	state.pattern["WARNING"].stages = {}

	if NetworkDoesEntityExistWithNetworkId(netId) then
		state.entity = NetworkGetEntityFromNetworkId(netId)
		LoadConfigurationIntoState(state)
	end

	SavedVehicles[netId] = state

	return state
end

function GetSavedVehicleStateUsingEntity(entity)
	local netId = NetworkGetNetworkIdFromEntity(entity)

	if netId == 0 then return nil end

	return GetSavedVehicleState(netId)
end

function CheckVehicleStates()
	for k, v in pairs(EnabledVehicles) do
		if not DoesEntityExist(v) then
			VehicleLeftScope(k, SavedVehicles[k])
		end
	end

	for k, v in pairs(SavedVehicles) do
		if not EnabledVehicles[k] then
			if NetworkDoesEntityExistWithNetworkId(k) then
				VehicleEnteredScope(k, v)
			end
		end
	end
end

function VehicleEnteredScope(netId, state)
	local entity = NetworkGetEntityFromNetworkId(netId)

	if entity == 0 then return end

	EnabledVehicles[netId] = entity

	state.entity = entity

	if not state.config then
		LoadConfigurationIntoState(state)
	end

	SetVehicleAutoRepairDisabled(entity, true)
	SetVehicleHasMutedSirens(entity, true)

	for patternName, v in pairs(Config.Pattern) do
		if patternName ~= "LUKE" and state.pattern[patternName].enabled then
			SetVehicleSiren(entity, true)
		end
	end

	if state.siren.tone ~= 0 and not state.siren.handle then
		Controller.OnSirenChange(state)
	end

	if state.bullhorn.enabled and not state.bullhorn.handle then
		Controller.OnBullhornChange(state)
	end
end

function VehicleLeftScope(netId, state)
	EnabledVehicles[netId] = nil

	if state.siren.tone ~= 0 and state.siren.handle then
		--StopSound(state.siren.handle)
		--ReleaseSoundId(state.siren.handle)
		state.siren.handle = nil
	end

	if state.bullhorn.enabled and state.siren.handle then
		--StopSound(state.bullhorn.handle)
		--ReleaseSoundId(state.bullhorn.handle)
		state.bullhorn.handle = nil
	end

	state.entity = nil
end

function LoadConfigurationIntoState(state)
	local config = VehicleConfigs[GetEntityModel(state.entity)]

	state.bullhorn.configEnabled = config.sirens.bullHorn
	state.bullhorn.sound = config.sirens.bullHornSound

	state.siren.configEnabled = config.sirens.enabled
	state.siren.sounds = config.sirens.sounds

	local patternType = config.lightSetup.lightPattern
	
	local primary = Config.Pattern["PRIMARY"][patternType]
	if not primary then primary = Config.Pattern["PRIMARY"]["leds"] end
	state.pattern["PRIMARY"].stages = primary

	local isLuke = config.lightSetup.useDifferentOnScene

	if isLuke then
		state.pattern["REARPRIMARY"].stages = Config.Pattern["LUKE"]
	else
		local rearPrimary = Config.Pattern["REARPRIMARY"][patternType]
		if not rearPrimary then rearPrimary = Config.Pattern["REARPRIMARY"]["leds"] end
		state.pattern["REARPRIMARY"].stages = rearPrimary
	end

	local secondary = Config.Pattern["SECONDARY"][patternType]
	if not secondary then secondary = Config.Pattern["SECONDARY"]["leds"] end
	state.pattern["SECONDARY"].stages = secondary

	local warning = Config.Pattern["WARNING"][patternType]
	if not warning then warning = Config.Pattern["WARNING"]["leds"] end
	state.pattern["WARNING"].stages = warning

	state.extras = {}

	for k, v in pairs(config.extras) do
		local extra = {}
		extra.enabled = v.enabled
		extra.lighting = v.allowEnvLight
		extra.colour = v.colour

		if not v.offSetX or not v.offSetY or not v.offSetZ then
			extra.offset = vector3(0.0, 0.0, 0.0)
		else
			extra.offset = vector3(tonumber(v.offSetX), tonumber(v.offSetY), tonumber(v.offSetZ))
		end
		
		extra.rotations = {}
		
		local id = tonumber(string.sub(k, 6))
		state.extras[id] = extra
	end

	for k, v in pairs(config.extraRotations) do
		local id = tonumber(string.sub(k, 6))
		local extra = state.extras[id]

		for i, v in ipairs(v) do
			--[[if isLuke then
				extra.rotations[#extra.rotations + 1] = vector3(tonumber(v.rotateX), -(tonumber(v.rotateY)), tonumber(v.rotateZ))
			else]]
				extra.rotations[#extra.rotations + 1] = vector3(tonumber(v.rotateX), tonumber(v.rotateY), tonumber(v.rotateZ))
			--[[end]]
		end
	end

	state.config = {}
	state.config.name = config.name
	state.config.secondaryWithPrimary = config.lightSetup.secondaryWithPrimary
	state.config.warningWithPrimary = config.lightSetup.warningWithPrimary
end
