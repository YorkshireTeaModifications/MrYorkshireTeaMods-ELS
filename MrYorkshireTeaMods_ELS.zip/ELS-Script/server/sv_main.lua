local els = {}

RegisterNetEvent("ELS:ChangeStage")
AddEventHandler("ELS:ChangeStage", function(stage)

    local net = GetNetVehicle(source)

        if net == 0 then return end

    TriggerClientEvent('ELS:ChangeStage', -1,source,net,stage)
end)

RegisterNetEvent("ELS:ToggleSiren")
AddEventHandler("ELS:ToggleSiren", function(tone)

    local net = GetNetVehicle(source)

        if net == 0 then return end

    TriggerClientEvent('ELS:ToggleSiren', -1,source,net,tone)
end)

RegisterNetEvent("ELS:ToggleBullhorn")
AddEventHandler("ELS:ToggleBullhorn", function(bullHorn)

    local net = GetNetVehicle(source)

        if net == 0 then return end

    TriggerClientEvent('ELS:ToggleBullhorn', -1,source,net,bullHorn)
end)

RegisterNetEvent("ELS:PatternChange")
AddEventHandler("ELS:PatternChange", function(name,enabled)

    local net = GetNetVehicle(source)

        if net == 0 then return end

    TriggerClientEvent('ELS:PatternChange', -1,source,net,name,enabled)
end)

AddEventHandler("entityRemoved", function(entity)
    local net = els[entity]
    if net then
        TriggerClientEvent("ELS:VehicleRemoved", -1, net)
        els[entity] = nil
    end
end)


function GetNetVehicle(player)    
    local ped = GetPlayerPed(player)

    if ped == 0 then return 0 end

    local veh = GetVehiclePedIsIn(ped, false)

    if veh == 0 then return 0 end

    local net = NetworkGetNetworkIdFromEntity(veh)

    if net == 0 then return 0 end

    els[veh] = net

    return net
end