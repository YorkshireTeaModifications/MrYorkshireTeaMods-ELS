fx_version "bodacious"
games { "gta5" }

author 'MrYorkshireTea Modifications'
description 'A Standard ELS System made for British Servers, You can Customise this with any siren sounds of choice'
version '1.0'

lua54 "yes"

files { "config.json", "patterns/*.json", "vcfs/*.json" }

client_scripts { "client/*.lua" }
server_scripts { "server/*.lua" }

files { 
    "dlc_xcustom/*.awc",
	"data/xcustom_sounds.dat54.nametable",
	"data/xcustom_sounds.dat54.rel"
}

export "ELSStageChangeForVehicle"

data_file "AUDIO_WAVEPACK" "dlc_xcustom"
data_file "AUDIO_SOUNDDATA" "data/xcustom_sounds.dat"